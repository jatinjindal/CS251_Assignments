<html>
<head>

</head>
<body>


<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
 
<h2 align="center">Admin Login</h2>

<p>Name: <input id="name" name = "Name" value="" /></p>
<font color = "red"><p id="demo"></p></font>

<p>Password: <input type = "password" id="password" name = "Password" value="" /></p>
<font color = "red"><p id="demo1"></p></font>

<input type="submit">



</form>


<?php

$db = new SQLite3('mysqlitedb.db');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	$name = $_POST["Name"];
  	$password = $_POST["Password"];
  	if($name == "admin" && $password == "admin")
  	{
  		echo "<h2>Records:</h2>";
		$results = $db->query('SELECT * FROM records');
		//echo "Name Address Email Phone_Number Account_Number";
		echo "<table style=\"width:100%\">";
		echo "<tr> <th>Name</th> <th>Address</th> <th>Email</th> <th>Phone Number</th> <th>Acc Number</th> </tr>";
		while ($row = $results->fetchArray()) {
		
	 	   echo "<tr> <td>$row[0]</td> <td>$row[1]</td> <td>$row[2]</td> <td>$row[3]</td> <td>$row[4]</td> </tr>";
		}
		echo "</table>";
	}
  	else
  	{
  		echo "<font color =\"red\" <br> Invalid Username/Password </font> <br>  ";
  	}


}

$link_address1 = 'main.php';
echo "<a href='$link_address1'>Another Registration</a>";



?>

</body>
</html>
