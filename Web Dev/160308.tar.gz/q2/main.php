
<html>
<head>
<script type="text/javascript" src = "script.js">
</script>
</head>


<body>  


<form method="post"  onsubmit="return myFunction()"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  
<h1 align="center">Let's Build Stuff</h1>
<h2 align="center">Registration</h2>

<p>Name: <input id="name" value=""  name="Name" ></p>
<font color = "red"><p id="demo"></p></font>

<p>Address: <input id="address" value="" name = "Address"/></p>
<font color = "red"><p id="demo1"></p></font>

<p>Email: <input id="email" value="" name = "Email"/></p>
<font color = "red"><p id="demo2">  </p></font> 

<p>Mobile Number: <input id="phone" value="" name="Mobile_Number" /></p>
<font color = "red"><p id="demo3"></p></font>

<p>Bank Account Number: <input id="acc" value="" name = "Bank_Account_Number"/></p>
<font color = "red"><p id="demo4"></p></font>

<p>Bank Password: <input type="password" id="pass" value="" name = "Bank_Password" /></p>
<font color = "red"><p id="demo5"></p></font>

<button type="submit">Submit</button>

</form>


<?php

// define variables and set to empty values
$name = $address = $email = $phone = $acc = $pass = "";
$db = new SQLite3('mysqlitedb.db');
/*$db->query("Create table records(Name Varchar(20),Address Varchar(100),Email Varchar(100),Mobile_Number INT(10),Bank_Account_Number INT(5),Bank_Password Varchar(20))");
$db->query("Create table banksheet(Bank_Account_Number INT(5),Bank_Password Varchar(20), Account_Balance INT(10))");

$qstr = "insert into banksheet values ('00000', '0', '100')";
$insres = $db->query($qstr);
$qstr = "insert into banksheet values ('11111', '1', '1111')";
$insres = $db->query($qstr);
*/



if ($_SERVER["REQUEST_METHOD"] == "POST") {
  //echo "adfdsds";
  $name = $_POST["Name"];
  $address = $_POST["Address"];
  $email = $_POST["Email"];
  $phone = $_POST["Mobile_Number"];
  $acc = $_POST["Bank_Account_Number"];
  $pass = $_POST["Bank_Password"];
  $results = $db->query("SELECT * FROM records WHERE Email like '".$email."' ");
  //echo "check2";
  if (( $results->fetchArray() ) )
    {
        //echo "xyz";       
        echo "<br> <font color = \"red\"> Already registered </font> <br>";
    }
    else
    {
        $cor_password = $db->query("SELECT * FROM banksheet WHERE Bank_Account_Number like '".$acc."' ");
        // $c1 = $db->query("SELECT * FROM banksheet WHERE Bank_Account_Number like '".$acc."' ");
        $cash = $cor_password->fetchArray();
	
	if($cash[1] != $pass)
	{
		echo "<br> <font color = \"red\"> Invalid account/password </font> <br>";
	}
	else if ($cash[2] > 1000)
        {
		$cash[2] = $cash[2] - 1000;
		if ($cash[1] == $pass)
		{
		    $temp = $db->query("UPDATE banksheet SET Account_Balance='".$cash[2]."' WHERE Bank_Account_Number = '".$acc."' ");
		    $qstr = "insert into records values ('$name', '$address', '$email', '$phone','$acc','$pass')";
		    $insres = $db->query($qstr);
		    echo "<br> <font color = \"red\">  New Member Registered </font> <br>";
		}

        }
        else
        {
        	echo "<br>  <font color = \"red\"> Insufficient balance </font> <br>";
        }

    } 
}

$link_address1 = 'second.php';
echo "<a href='$link_address1'>See All registrations</a>";

?>



</body>
</html>

