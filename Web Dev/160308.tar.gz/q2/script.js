

function myFunction() {
    var name, checkname, printname, flag;
    flag =0;
    name = document.getElementById("name").value;
    checkname = /^[a-z A-Z]{1,20}$/.test(name);
    printname = checkname ? "" : "Invalid Name";
    if (!checkname)
    {
        flag = 1;
    }
    document.getElementById("demo").innerHTML = printname;
    
    
    var address, n, printaddress;
    address = document.getElementById("address").value;
    n = address.length;
    if (n <1 || n>100)
    {
        flag=1;
    }
    printaddress = (n>0 && n<101) ? "" : "Invalid address";
    document.getElementById("demo1").innerHTML = printaddress;
    
    
    var email, checkemail, printemail;
    email = document.getElementById("email").value;
    checkemail = /^[a-zA-Z]+@.+\.com$/.test(email);
    if(!checkemail)
    {
        flag=1;
    }
    printemail = checkemail ? "" : "Invalid email";
    document.getElementById("demo2").innerHTML = printemail;
    
    var phone, checkphone, printphone;
    phone = document.getElementById("phone").value;
    checkphone = /^[1-9][0-9]{9}$/.test(phone);
    if(!checkphone)
    {
        flag=1;
    }
    printphone = checkphone ? "" : "Invalid Mobile Number";
    document.getElementById("demo3").innerHTML = printphone;
    
    var acc, checkacc, printacc;
    acc = document.getElementById("acc").value;
    checkacc = /^[0-9]{5}$/.test(acc);
    if(!checkacc)
    {
        flag=1;
    }
    printacc = checkacc ? "" : "Invalid Account Number";
    document.getElementById("demo4").innerHTML = printacc;
    
    var password, checkpass, printpass;
    password = document.getElementById("pass").value;
    checkpass = /^[0-9a-zA-Z]{1,20}$/.test(password);
    if(!checkpass)
    {
        flag=1;
    }
    printpass = checkpass ? "" : "Invalid password";
    document.getElementById("demo5").innerHTML = printpass;
    if(flag == 1)
    {
        return false;
    }
    else
    {
        return true;
    }

}
s
