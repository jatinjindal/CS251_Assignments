num_samples <- 50000
data <- rexp(num_samples, 0.2)
x <- data.frame(X = seq(1, num_samples , 1), Y = sort(data))
plot(x,type="p",xlab="numbers",main = "Scatter plot",ylab="values from exponential distribution")

# ---------------------Step2 ------------------------------

#print(data)
b <- split(data, ceiling(seq_along(data)/100))
#print(b[500])

#---------------Step3 -----------------------------------


pdata <- rep(0, 100);
#print(b[1])
temp <- unlist(b[1],use.names=FALSE)
#print(temp)
#print(temp[1])
str(temp)
for(i in 1:100){
    val=round(temp[i], 0);
    #str(val)
    if(val <= 100){
       pdata[val] = pdata[val] + 1/ 100; 
    }
}

xcols <- c(0:99)

#str(pdata)
#str(xcols)

plot(xcols, pdata, "l", main = "First Sample" , xlab="X", ylab="f(X)")

cdata <- rep(0, 100)

cdata[1] <- pdata[1]

for(i in 2:100){
    cdata[i] = cdata[i-1] + pdata[i]
}

plot(xcols, cdata, "o",main = "First Sample", col="blue", xlab="X", ylab="F(X)");

#----------------------------

pdata <- rep(0, 100);
#print(b[1])
temp <- unlist(b[2],use.names=FALSE)
#print(temp)
#print(temp[1])
str(temp)
for(i in 1:100){
    val=round(temp[i], 0);
    #str(val)
    if(val <= 100){
       pdata[val] = pdata[val] + 1/ 100; 
    }
}

xcols <- c(0:99)

#str(pdata)
#str(xcols)

plot(xcols, pdata, "l",main = "Second Sample", xlab="X", ylab="f(X)")

cdata <- rep(0, 100)

cdata[1] <- pdata[1]

for(i in 2:100){
    cdata[i] = cdata[i-1] + pdata[i]
}

plot(xcols, cdata, "o", main = "Second Sample", col="blue", xlab="X", ylab="F(X)");


#----------------------------

pdata <- rep(0, 100);
#print(b[1])
temp <- unlist(b[3],use.names=FALSE)
#print(temp)
#print(temp[1])
str(temp)
for(i in 1:100){
    val=round(temp[i], 0);
    #str(val)
    if(val <= 100){
       pdata[val] = pdata[val] + 1/ 100; 
    }
}

xcols <- c(0:99)

#str(pdata)
#str(xcols)

plot(xcols, pdata, "l", main = "Third Sample",xlab="X", ylab="f(X)")

cdata <- rep(0, 100)

cdata[1] <- pdata[1]

for(i in 2:100){
    cdata[i] = cdata[i-1] + pdata[i]
}

plot(xcols, cdata, "o", main = "Third Sample", col="blue", xlab="X", ylab="F(X)");
#----------------------------

pdata <- rep(0, 100);
#print(b[1])
temp <- unlist(b[4],use.names=FALSE)
#print(temp)
#print(temp[1])
str(temp)
for(i in 1:100){
    val=round(temp[i], 0);
    #str(val)
    if(val <= 100){
       pdata[val] = pdata[val] + 1/ 100; 
    }
}

xcols <- c(0:99)

#str(pdata)
#str(xcols)

plot(xcols, pdata, "l", main= "Fourth Sample",xlab="X", ylab="f(X)")

cdata <- rep(0, 100)

cdata[1] <- pdata[1]

for(i in 2:100){
    cdata[i] = cdata[i-1] + pdata[i]
}

plot(xcols, cdata, "o", main = "Fourth Sample",col="blue", xlab="X", ylab="F(X)");
#----------------------------

pdata <- rep(0, 100);
#print(b[1])
temp <- unlist(b[5],use.names=FALSE)
#print(temp)
#print(temp[1])
str(temp)
for(i in 1:100){
    val=round(temp[i], 0);
    #str(val)
    if(val <= 100){
       pdata[val] = pdata[val] + 1/ 100; 
    }
}

xcols <- c(0:99)

#str(pdata)
#str(xcols)

plot(xcols, pdata, "l",main = "Sample-5", xlab="X", ylab="f(X)")

cdata <- rep(0, 100)

cdata[1] <- pdata[1]

for(i in 2:100){
    cdata[i] = cdata[i-1] + pdata[i]
}

plot(xcols, cdata, "o",main="Sample-5", col="blue", xlab="X", ylab="F(X)");

#-------------CACULATE MEAN -------------------------

M <- rep(0.0,500)
S <- rep(0.0,500)
for(i in 1:500){
	temp <- unlist(b[i],use.names=FALSE)
	M[i] <- mean(temp)
	S[i] <- sd(temp)
}
paste("Mean1 = ",M[1])
paste("Sd1= ",S[1])
paste("Mean2 =",M[2])
paste("Sd2 =",S[2])
paste("Mean3 = ",M[3])
paste("Sd3 = ",S[3])
paste("Mean4 =",M[4])
paste("Sd4 = ",S[4])
paste("Mean5 = ",M[5])
paste("Sd5 =",S[5])

#print(M)

#---------------------STEP4--------------------------------


tab <- table(round(M,1))
plot(tab, "h", xlab="Value",main = "Distribution of Sample Mean", ylab="Frequency")

pdata <- rep(0, 100);
for(i in 1:500){
    val=round(M[i], 0);
    if(val <= 100){
       pdata[val] = pdata[val] + 1/ 500; 
    }
}

xcols <- c(0:99)

plot(xcols, pdata, "l",main = "Distribution of Sample Mean", xlab="X", ylab="f(X)")

cdata <- rep(0, 100)

cdata[1] <- pdata[1]

for(i in 2:100){
    cdata[i] = cdata[i-1] + pdata[i]
}

plot(xcols, cdata, "o", col="blue",main = "Distribution of Sample Mean", xlab="X", ylab="F(X)");


#--------------------STEP5-------------------------

finalmean <- mean(M)
finalsd <- sd(M)
paste("Calculated Mean =",finalmean)
paste("Calculate Sd=",finalsd)

truemean <- 5
truesd <- 5
expsd <- 0.5
paste("TrueMean = ",truemean)
paste("TrueSd = ",truesd)
paste("ExpSd = ",expsd)



