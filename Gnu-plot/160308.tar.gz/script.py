import  math

file = open("threads.txt","r")
threads = []

for line in file:
	for i in line.split():
		threads.append(i)

#print threads

file.close(	)


file = open("params.txt","r")
params = []

for line in file:
	for i in line.split():
		params.append(i)

#print params

file.close(	)

file = open("runtest","r")
timevalue = []

for line in file:
	count=0
	for i in line.split():
		if count==3:
			timevalue.append(i)
		count = count+1

#print len(timevalue)
file.close()

i=0

index =0
file = open("analyse","w+")
i=0
j=0
#print len(timevalue)
while index < len(timevalue):
	avg1=0.0
	for count in range(0,100):
		avg1 = avg1 + int(timevalue[index + count])
	avg1 = float(avg1/100)
	var1=0.0
	e2=0.0
	e1=0.0
	for count in range(0,100):
		t = float(timevalue[index + count])
		e2 = e2 + (1/t)*(1/t)*avg1*avg1
		e1 = e1 + (avg1/t)		
	e2 = e2/100
	e1 = e1/100
	var1 = e2 - e1*e1	
	
	index = index + count + 1

	avg2=0.0
	
	for count in range(0,100):
		avg2 = avg2 + int(timevalue[index + count])
	avg2 = float(avg2/100)
	
	e2=0.0
	e1=0.0
	for count in range(0,100):
		t = float(timevalue[index + count])		
		e2 = e2 + (1/t)*(1/t)*avg1*avg1
		e1 = e1 + (avg1/t)
	#print var2
	e2 = e2/100
	e1 = e1/100
	var2 = e2 - e1*e1
	index = index + count + 1

	

	avg3=0.0
	for count in range(0,100):
		avg3 = avg3 + int(timevalue[index + count])
	avg3 = float(avg3/100) 
	var3=0.0
	e2=0.0
	e1=0.0
	for count in range(0,100):
		t = float(timevalue[index + count])		
		e2 = e2 + (1/t)*(1/t)*avg1*avg1
		e1 = e1 + (avg1/t)
	e2 = e2/100
	e1 = e1/100
	var3 = e2 - e1*e1
	index = index + count + 1

	
	avg4=0.0
	for count in range(0,100):
		avg4 = avg4 + int(timevalue[index + count])
	avg4 = float(avg4/100)
	var4=0.0
	e2=0.0
	e1=0.0
	for count in range(0,100):
		t = float(timevalue[index + count])
		e2 = e2 + (1/t)*(1/t)*avg1*avg1
		e1 = e1 + (avg1/t)		
	e2 = e2/100
	e1 = e1/100
	var4 = e2 - e1*e1	
	index = index + count + 1	

	avg5=0.0
	for count in range(0,100):
		avg5 = avg5 + int(timevalue[index + count])
	avg5 = float(avg5/100)
	var5=0.0
	e2=0.0
	e1=0.0
	for count in range(0,100):
		t = float(timevalue[index + count])		
		e2 = e2 + (1/t)*(1/t)*avg1*avg1
		e1 = e1 + (avg1/t)
	
	e2 = e2/100
	e1 = e1/100
	var5 = e2 - e1*e1
	index = index + count + 1
	#print avg1
	#print avg2
	#print avg3
	#print avg4
	#print avg5
	#print ("index = %d",index)
	#print i
	#print index
	temp = str(params[i]) + " " + str(avg1) + " " + str(avg2) + " " + str(avg3) + " " + str(avg4) + " " + str(avg5) + " " + str(var1)

	temp = temp + " " + str(var2) + " " + str(var3) + " " + str(var4) + " " + str(var5)
	file.write(temp + "\n")
	i = i +1

file.write("\n")

i=0
index=0	
while index < len(timevalue):
	count=0
	while count<100:
		temp = str(params[i]) + " " + str(timevalue[index+count])
		file.write(temp + "\n")
		count = count+1
	index = index + 500
	i = i + 1

file.write("\n")
index=100
i=0
while index < len(timevalue):
	count=0
	while count<100:
		temp = str(params[i]) + " " + str(timevalue[index+count])
		file.write(temp + "\n")
		count = count+1
	index = index + 500
	i = i + 1
file.write("\n")

index=200
i=0
while index < len(timevalue):
	count=0
	while count<100:
		temp = str(params[i]) + " " + str(timevalue[index+count])
		file.write(temp + "\n")
		count = count+1
	index = index + 500
	i = i + 1
file.write("\n")

index=300
i=0
while index < len(timevalue):
	count=0
	while count<100:
		temp = str(params[i]) + " " + str(timevalue[index+count])
		file.write(temp + "\n")
		count = count+1
	index = index + 500
	i = i + 1
file.write("\n")

index=400
i=0
while index < len(timevalue):
	count=0
	while count<100:
		temp = str(params[i]) + " " + str(timevalue[index+count])
		file.write(temp + "\n")
		count = count+1
	index = index + 500
	i = i + 1

file.close()

