#!/bin/bash
count=0
file1=$1
file2=$2

cat $file1 | while read -r line1 || [[ -n "$line1" ]];
do
	cat $file2 | while read -r line2 || [[ -n "$line2" ]];
	do
		for i in $line1;
		do
			for j in $line2;
			do
				while [[ $count -lt "100" ]];
				do
					count=$(($count+1))					
					result=$( ./APP $i $j )
					echo $result >> runtest
				done	
				count=0		
				
			done
		done	
	done
done

