import os
import csv
import sys
import numpy as np
import matplotlib.pyplot as plt


#----------------------STEP1---------------------------------------------------
X = []
Y = []
flag=0
with open('train.csv', 'rb') as csvfile:
	for line in csvfile.readlines():
		if flag==0:
			flag=1
			continue
		array = line.split(',')
		X.append(float(array[0]))
		temp = array[1]
		y = temp.split('\n')
		Y.append(float(y[0]))


X = np.array(X)
Y = np.array(Y)
x=X
y = Y
m = len(X)
X = X.reshape((m,1))
Y = Y.reshape((m,1))
one = np.ones((m,1))
X = np.concatenate((one,X),axis=1)

# X is X_train and Y is Y_train
#x is the list containing features and y is the value

#----------------STEP2---------------------------------------------------------
w = np.random.rand(2,1)
w[0] = w[0]
w[1] = w[1]

# w is the random vector

#----------------Step3------------------------------------------------------


z=x
ydash = w[0] + w[1]*z

plt.plot(x,y,"*")
plt.plot(z,ydash,'r')
plt.show()

#------------------Step4----------------------------------------------

X_train = np.matrix(X)
X_train_tr = np.matrix(X.transpose())
temp = (X_train_tr * X_train)
temp = np.linalg.inv(temp)
temp = temp * X_train_tr
Y_train = np.matrix(Y)
w_direct = temp * Y
k = x
ans = w_direct[0,0] + w_direct[1,0]*k

plt.plot(x,y,"*")
plt.plot(k,ans,'g')
plt.show()

#----------------Step5----------------------------------------------


for i in range(0,2):
	for j in range(0,m):
		a = x[j]
		b = y[j]
		eta = 0.000000001
		c=a**2
		temp = w[0,0] - eta*w[0,0] - eta*w[1,0]*a + eta *b
		temp2 = eta*w[0,0]*a + eta*w[1,0]*c - eta*b*a
		w[1,0] = w[1,0] - temp2
		w[0,0] = temp
		if j%1000 == 0:
			z=x
			ydash = w[0] + w[1]*z
			plt.plot(z,ydash,'r')
			#plt.plot(x,y,"*")


plt.show()

#------------------Step6----------------------------------------------
			
k = x
ans = w[0] + w[1]*k
plt.plot(x,y,"b+")
plt.plot(k,ans,'r')
plt.show()

#--------------------Step7----------------------------------------------



X_test = []
Y_test = []
flag=0
with open('test.csv', 'rb') as csvfile:
	for line in csvfile.readlines():
		if flag==0:
			flag=1
			continue
		array = line.split(',')
		X_test.append(float(array[0]))
		temp = array[1]
		z = temp.split('\n')
		Y_test.append(float(z[0]))

n = len(X_test)
X_test = np.array(X_test)
Y_test = np.array(Y_test)
X_test = X_test.reshape((n,1))
Y_test = Y_test.reshape((n,1))
one = np.ones((n,1))
X_test = np.concatenate((one,X_test),axis=1)
X_test = np.matrix(X_test)
Y_test = np.matrix(Y_test)
Y_pred1 = X_test*w
Y_pred2 = X_test*w_direct
Error1 = Y_pred1 - Y_test
Error2 = Y_pred2 - Y_test
Error1 = np.array(Error1)
Error2 = np.array(Error2)
t1= np.sqrt(np.mean(Error1**2))
print t1
t2= np.sqrt(np.mean(Error2**2))
print t2