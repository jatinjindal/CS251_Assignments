from decimal import * 
data = raw_input()
#print str

#check for the number after the decimal
#consider the case when decimal is at the starting
base = input()
flag=0
index=0
neg=0
decimal=0
place=-1
for i in data:
	#print i
	if i >='0' and i<='9':
		value = ord(i) - ord('0')
		if value >= base:
			flag=1
			break
		#print i
	
	elif i >= 'A' and i <= 'Z':
		value = 10 + ord(i) - ord('A')
		#print value
		if value>=base:
			flag=1
			break
		#print i
	
	elif i=='-':		#check for negative numbers
		if index==0:
			neg=1
			
		else:
			flag=1
			break
	

	elif i=='.':	
		#check for rational numbers
		#if index ==1 and data[0]=='-':
		#	flag=1
	#		break
			
		if decimal==0:
			decimal=1
			place = index
		else:
			flag=1
			break
	else:
		flag=1
		break

	index+=1





if flag==1:
	print "Invalid Input"

else:
	if decimal==0:
		power = index - neg -1
	else:
		power = place - neg -1
		#print power

	number =0 
	for i in data:
		if i=='-' or i=='.':
			continue
		else:
			if i >='0' and i<='9':
				value = ord(i)-ord('0')
			else:
				value = ord(i)-ord('A')+10
			
			if power>0:
				number = number + (base**power)*value
			elif power == 0:
				number = number + value
			else:
				k= power * (-1)
				number = number + float(value)/(base **k)
			#print ("number = %d",number)
			#print ("power = %d",power)
			#print( "value = %d \n", value)
			power-=1
	
	if neg==1:
		temp = str(number)
		ans = "-" + temp
		print Decimal(ans)
	else:		
		print Decimal(number)

	
